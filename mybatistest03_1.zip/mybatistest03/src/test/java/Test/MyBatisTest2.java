package Test;
import java.io.*;

import com.itheima.dao.OrdersMapper;
import com.itheima.dao.PersonMapper;
import com.itheima.dao.UsersMapper;
import com.itheima.pojo.Orders;
import com.itheima.pojo.Person;
import com.itheima.pojo.Users;
import com.itheima.utils.MyBatisUtils;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

public class MyBatisTest2 {
    @Test
    public void selectPersonByIdTest()
    {
        SqlSession session = MyBatisUtils.getSession();
        PersonMapper mapper = session.getMapper(PersonMapper.class);
        Person person = mapper.selectPersonById(2);
        System.out.println(person.toString());
        session.close();
    }
@Test
    public void selectUserByIdTest(){
        SqlSession session=MyBatisUtils.getSession();
    UsersMapper mapper=session.getMapper(UsersMapper.class);
    Users users=mapper.selectUserById(1);
    System.out.println(users.toString());
    session.close();

    }

    @Test
    public void selectOrdersByIdTest(){
        SqlSession session=MyBatisUtils.getSession();
        OrdersMapper mapper=session.getMapper(OrdersMapper.class);
        Orders orders = mapper.selectOrdersById(3);
        System.out.println(orders.toString());
        session.close();
    }
}
